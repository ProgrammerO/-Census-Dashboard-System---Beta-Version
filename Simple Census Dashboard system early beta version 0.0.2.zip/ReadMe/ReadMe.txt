Simple Census Dashboard system early beta version 0.0.2


How to run?

1- Extract to folder

2- double click on "Simple Censusess System.exe" and enjoy the demo :) .




for any comments or feedback please find me on my github: 

https://github.com/ProgrammerO


This is beta version.